#!/bin/bash

touch newfile
echo "kjqls" > newfile
